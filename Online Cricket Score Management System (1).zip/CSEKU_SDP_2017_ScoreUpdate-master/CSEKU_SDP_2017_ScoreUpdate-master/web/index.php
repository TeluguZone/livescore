<!DOCTYPE html>
<html>
<head>
	<title> Live Scores &amp; Updates </title>
	<link   rel="stylesheet" href="css/style.css" type="text/css"> </link>
</head>
<body>
<div>
	<header>
		<h1>Live Scores</h1>
	</header>
	<nav>
	   <ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="liveScores.php" ""target="_blank">Live scores</a></li>
			<li><a href="#">Schedule</a></li>
			<li><a href="#">News</a></li>
			<li><a href="#">About</a></li>

	   </ul>
	</nav>
	<section>
		
	</section>
	<footer>
		<p>copyright &copy; Md. Moniruzzaman Aurangzeb</p>
	</footer>
</body>
</html>